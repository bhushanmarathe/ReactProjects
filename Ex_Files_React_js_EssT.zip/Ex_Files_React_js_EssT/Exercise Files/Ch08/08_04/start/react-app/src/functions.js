export default function timesTwo(a) {
  return a * 2;
}
