export function Star() {
  return <h1>Cool Star</h1>;
}
